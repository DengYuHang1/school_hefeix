#include<iostream>
#include<vector>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include"file.h"

using namespace std;

void write(vector<Courier>& couriers)
{
    fstream afile;

    afile.open("Courier.txt", ios::out);//��courier����д���ļ���
    if (!afile.is_open())
    {
        cout << "Courier�ļ���ʧ��!" << endl;
    }
    else
    {
        for (int i = 0; i < couriers.size(); i++)
        {
            afile << couriers[i].name << " " << couriers[i].age << " " << couriers[i].number;
            afile << "  " << couriers[i].gender << "  " << couriers[i].phone << endl;
        }
    }
    afile.close();

    afile.open("Package.txt", ios::out);
    if (!afile.is_open())
    {
        cout << "Package�ļ���ʧ��!" << endl;
    }
    else
    {
        for (int i = 0; i < couriers.size(); i++)
        {
            afile << couriers[i].name << " " << couriers[i].packages.size() << endl;
            for (int j = 0; j < couriers[i].packages.size(); j++)
            {
                afile << setfill('0') << setw(2) << couriers[i].packages[j].deadline / 60 << ':';
                afile << setfill('0') << setw(2) << couriers[i].packages[j].deadline % 60 << " " << std::left << setw(3) << couriers[i].packages[j].profit;
                afile << "  " << couriers[i].packages[j].serve << endl;
            }
        }
    }
    afile.close();
}

void read(vector<Courier>& couriers, vector<Package>& packages,Manage& boss)
{
    fstream afile;  //�ȼ��package��Courier��Ӧ���ļ�
    afile.open("Courier.txt", ios::in);
    if (!afile.is_open())
    {
        cout << "Courier�ļ���ʧ��!" << endl;
    }
    else
    {
        while (!afile.eof())
        {
            string name, number, phone, line;
            int age, gender;
            getline(afile, line);
            istringstream iss(line);
            if (iss >> name >> age >> number >> gender >> phone)
            {
                Courier me(name, age, number);
                me.gender = gender;
                me.phone = phone;
                couriers.push_back(me);
            }
            else
            {
                if(name!="")cout << name << "Courier����ʧ��" << endl;
            }
        }
    }
    afile.close();

    afile.open("Package.txt", ios::in);
    if (!afile.is_open())
    {
        cout << "Package�ļ���ʧ��!" << endl;
    }
    else
    {
        while (!afile.eof())
        {
            string name;
            int sum, ret;
            afile >> name >> sum;
            //cout << name << sum<<endl;
            afile.get();
            ret = boss.isExist(couriers, name);
            for (int i = 0; i < sum && ret != -1; i++)
            {
                Package my_package;
                string line;
                getline(afile, line);// ÿ�ζ�ȡһ��
                int hour, minute, profit;
                int served;
                if (sscanf_s(line.c_str(), "%d:%d%d%d", &hour, &minute, &profit, &served) == 4) {
                    my_package.deadline = hour * 60 + minute;
                    my_package.profit = profit;
                    my_package.serve = served;
                    couriers[ret].packages.push_back(my_package);
                }
                else {
                    cout << "Package����ʧ��: " << line << i << "\n";
                    //���Իص��п�ͷ��
                    break;
                }
                //afile.get();
            }
        }
    }
    afile.close();
}